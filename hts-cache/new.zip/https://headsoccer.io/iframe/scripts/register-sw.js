"use strict";
{
    window.C3_RegisterSW = async function C3_RegisterSW() {
        
    };
}
